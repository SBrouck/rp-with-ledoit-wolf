# Robust Risk Parity under Covariance Uncertainty

**Author:** Sacha Brouck, MSBA (UW Foster)  
**Project:** Portfolio-grade quantitative analysis demonstrating rigorous methods, reproducibility, and practical decision-making under uncertainty.

## Project Overview

This project implements a robust risk parity allocation strategy that maintains stability when the covariance matrix is uncertain. The approach combines:

- **R**: Statistical estimation using Ledoit-Wolf shrinkage covariance
- **@RISK**: Monte Carlo simulation of covariance perturbations  
- **Evolver**: Optimization to maximize simulation-aware Sharpe ratio

The methodology addresses the critical challenge that traditional risk parity portfolios can become unstable when covariance estimates are noisy or time-varying.

## Problem Statement

Traditional equal risk contribution (ERC) portfolios assume perfect knowledge of the covariance matrix. In practice, covariance estimates are noisy and can lead to:

- Unstable portfolio weights
- Poor out-of-sample performance
- Excessive turnover and transaction costs
- Concentration risk during market stress

This project develops a robust alternative that explicitly accounts for covariance uncertainty through simulation-based optimization.

## Data Sources

- **ETF Prices**: Yahoo Finance via `tidyquant::tq_get` (adjusted prices)
- **Asset Universe**: SPY, TLT, LQD, HYG, GLD, DBC, VNQ, IWM, EFA, EEM
- **Risk-Free Rate**: FRED DGS1 (daily Treasury rates)
- **Date Range**: 2010-01-01 to present
- **Rebalancing**: Monthly endpoints

## Methodology

### 1. Rolling Covariance Estimation
- 2-year rolling window (504 trading days)
- Ledoit-Wolf shrinkage toward identity matrix
- Export latest estimates for Excel optimization

### 2. Baseline Strategies
- **Equal Weight (EW)**: 1/N portfolio
- **Minimum Variance (MV)**: Long-only variance minimization
- **Equal Risk Contribution (ERC)**: Traditional risk parity

### 3. Robust Optimization
- **@RISK Simulation**: 5,000 Latin Hypercube samples
- **Covariance Perturbations**: 
  - `alpha ~ Beta(2,6)`: Shrinkage intensity
  - `s ~ LogNormal(0, 0.10)`: Volatility scaling ±10%
  - `rho ~ Uniform(0.7, 1.0)`: Correlation dampening
- **Evolver Optimization**: Maximize P5(Sharpe) subject to constraints

### 4. Constraints
- Maximum weight: 30% per asset
- Turnover limit: 25% per month
- Transaction costs: 2.5 basis points per trade

## Repository Structure

```
robust-riskparity/
├── README.md                    # This file
├── config/
│   └── project.yaml            # Configuration parameters
├── data/
│   ├── prices.csv              # ETF adjusted prices
│   └── riskfree_dgs1.csv       # Risk-free rates
├── r/
│   ├── 01_download.R           # Data acquisition and QC
│   ├── 02_returns_cov.R        # Rolling covariance estimation
│   ├── 03_baselines_backtest.R # Baseline strategies
│   ├── 04_integrate_evolver.R  # Robust portfolio integration
│   ├── 05_figures.R            # Visualization
│   └── 99_utils.R              # Utility functions
├── excel/
│   ├── robust_rp_model.xlsx    # @RISK + Evolver workbook
│   └── README_Excel.md         # Excel setup instructions
└── out/
    ├── cov_rolling.csv         # Rolling covariance estimates
    ├── mu_rolling.csv          # Rolling mean estimates
    ├── latest_sigma.csv        # Latest covariance for Excel
    ├── latest_mu.csv           # Latest means for Excel
    ├── prev_weights.csv        # Previous weights
    ├── risk_results.csv        # @RISK simulation outputs
    ├── evolver_weights.csv     # Optimized weights
    ├── oos_performance.csv     # Out-of-sample results
    ├── fig_frontier.png        # Sharpe vs Robustness frontier
    └── fig_sharpe_dist.png     # Simulated Sharpe distribution
```

## How to Run

### Prerequisites
- R ≥ 4.3 with required packages
- Excel with @RISK and Evolver add-ins
- Internet connection for data download

### R Package Dependencies
```r
install.packages(c(
  "tidyquant", "dplyr", "tidyr", "readr", "lubridate", 
  "zoo", "corpcor", "quadprog", "riskParityPortfolio", 
  "PerformanceAnalytics", "ggplot2", "scales", "patchwork", 
  "yaml", "data.table"
))
```

### Execution Steps

1. **Data Download and Setup**
   ```r
   source("r/01_download.R")
   ```

2. **Covariance Estimation**
   ```r
   source("r/02_returns_cov.R")
   ```

3. **Baseline Strategies**
   ```r
   source("r/03_baselines_backtest.R")
   ```

4. **Excel Optimization**
   - Open `excel/robust_rp_model.xlsx`
   - Import latest covariance and mean estimates
   - Run @RISK simulation (5,000 iterations)
   - Use Evolver to optimize weights
   - Export results to `/out/` directory

5. **Integration and Analysis**
   ```r
   source("r/04_integrate_evolver.R")
   ```

6. **Visualization**
   ```r
   source("r/05_figures.R")
   ```

## Key Results

### Figure 1: Sharpe vs Robustness Frontier
The frontier plot demonstrates the trade-off between expected Sharpe ratio and robustness to covariance uncertainty. The robust-Evolver portfolio achieves:
- Higher Sharpe ratio than traditional ERC
- Better robustness (lower sensitivity to covariance perturbations)
- Improved risk-adjusted performance under uncertainty

### Figure 2: Simulated Sharpe Distribution
The distribution shows the range of possible Sharpe ratios under covariance uncertainty:
- P5 (5th percentile): Worst-case scenario performance
- P50 (median): Expected performance
- P95 (95th percentile): Best-case scenario performance

### Out-of-Sample Performance
The `oos_performance.csv` file contains comprehensive metrics for all strategies:
- Annualized Sharpe ratio
- Volatility and maximum drawdown
- Turnover and transaction costs
- Value at Risk (VaR) and Conditional VaR (CVaR)

## Key Insights

1. **Robustness Matters**: Traditional ERC can be unstable when covariance estimates are noisy
2. **Simulation-Based Optimization**: Accounting for parameter uncertainty improves out-of-sample performance
3. **Constraint Effectiveness**: Turnover and weight limits prevent excessive concentration
4. **Transaction Costs**: Realistic cost modeling is essential for practical implementation

## Limitations

- **Parameter Uncertainty**: Focus on covariance uncertainty; mean return uncertainty not modeled
- **Gaussian Assumptions**: VaR calculations assume normal returns
- **Friction Modeling**: Simplified transaction cost model
- **Survivorship Bias**: ETF universe may have survivorship bias
- **Look-Ahead Bias**: Rolling window approach minimizes but doesn't eliminate look-ahead

## Technical Notes

### Covariance Shrinkage
The Ledoit-Wolf estimator shrinks the sample covariance matrix toward a structured target (identity matrix), reducing estimation error while maintaining positive definiteness.

### Robust Optimization
The @RISK simulation generates 5,000 scenarios of perturbed covariance matrices, allowing optimization under uncertainty rather than point estimates.

### Performance Metrics
All metrics are calculated out-of-sample with proper transaction costs and realistic constraints to ensure practical applicability.

## Contact

Sacha Brouck  
MSBA Candidate, University of Washington Foster School of Business  
Email: [contact information]  
LinkedIn: [profile link]

---

*This project demonstrates advanced quantitative methods for portfolio optimization under uncertainty, suitable for buy-side applications and academic research.*
